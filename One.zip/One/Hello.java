package One;


	
	
	
	public class Hello {
		protected void display(){
			System.out.println("Able to Access From Hello1");
		}
	}

	
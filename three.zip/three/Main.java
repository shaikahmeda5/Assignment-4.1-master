package three;

	import two.Hello1;
	public class Main {
	    public static void main(String[] args) {
	    	Hello1 object1=new Hello1();
	    	object1.displayit();
	}
	}
	


package two;

	import One.Hello;
	public class Hello1 extends Hello {
		public void displayit(){
			display();
		}
		}


